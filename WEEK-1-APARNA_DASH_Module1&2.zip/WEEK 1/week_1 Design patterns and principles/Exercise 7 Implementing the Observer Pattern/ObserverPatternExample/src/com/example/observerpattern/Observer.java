package com.example.observerpattern;

public interface Observer {
	 void update(Stock stock);
}
