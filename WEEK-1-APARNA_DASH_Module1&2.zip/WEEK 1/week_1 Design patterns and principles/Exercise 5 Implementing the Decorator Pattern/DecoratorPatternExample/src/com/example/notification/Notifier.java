package com.example.notification;

public interface Notifier {
    void send(String message);
}
