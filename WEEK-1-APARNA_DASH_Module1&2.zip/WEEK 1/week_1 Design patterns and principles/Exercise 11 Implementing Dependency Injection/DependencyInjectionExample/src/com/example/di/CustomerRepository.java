package com.example.di;

public interface CustomerRepository {
    Customer findCustomerById(int id);
}
