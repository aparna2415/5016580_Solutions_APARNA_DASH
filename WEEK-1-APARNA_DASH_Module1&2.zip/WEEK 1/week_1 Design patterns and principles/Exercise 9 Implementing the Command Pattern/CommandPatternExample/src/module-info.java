/**
 * 
 */
/**
 * 
 */
module CommandPatternExample {
}