package com.example.payment;

public interface PaymentProcessor {
    void processPayment(double amount);
}
