package com.example.strategypattern;

public interface PaymentStrategy {
    void pay(int amount);
}
