INSERT INTO book (id, title, author, price, isbn) VALUES (1, 'Book Title 1', 'Author 1', 19.99, '1111111111111');
INSERT INTO book (id, title, author, price, isbn) VALUES (2, 'Book Title 2', 'Author 2', 29.99, '2222222222222');
